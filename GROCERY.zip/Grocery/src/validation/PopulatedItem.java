package validation;
import core_classes.Grocery;
import core_classes.GroceryItem;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class PopulatedItem {
//String name, int pricePerUnit, LocalDate stockDate, LocalTime stockTime)
	public static List<Grocery>populatedList(){
		ArrayList<Grocery>list=new ArrayList<>();
		list.add(new Grocery("BREAD",10,"2023-10-10","00:00:00"));
		list.add(new Grocery("BUTTER",20,"2023-05-10","00:00:00"));
		list.add(new Grocery("MILK",05,"2023-04-10","00:00:00"));
		list.add(new Grocery("EGG",50,"2023-03-10","00:00:00"));
		return list;
		
	}
}
