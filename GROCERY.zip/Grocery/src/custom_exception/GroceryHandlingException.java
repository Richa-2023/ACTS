package custom_exception;

public class GroceryHandlingException extends Exception {
	public GroceryHandlingException(String ErrorMsg) {
		super(ErrorMsg);
	}
}
