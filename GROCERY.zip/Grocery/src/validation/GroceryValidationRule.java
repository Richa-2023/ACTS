package validation;

public class GroceryValidationRule {

}
