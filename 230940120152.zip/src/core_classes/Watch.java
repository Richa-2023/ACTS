package core_classes;

import java.time.LocalDate;

public class Watch {
private int id;
private static int idGenerator;
private String name;
private Category category;
private Brand brand;
private Shape shape;
private Style style;
private WatchBrandMaterial material;
private int quantity;
private LocalDate stockListingDate;
private LocalDate stockUpdateDate;
private int price;
private int discounts;

static {
	idGenerator=0;
}

public Watch( String name,Category category, Brand brand, Shape shape, Style style, WatchBrandMaterial material,
		int quantity, LocalDate stockListingDate, int price, int discounts) {
	super();
	this.id = ++idGenerator;
	this.name = name;
	this.category = category;
	this.brand = brand;
	this.shape = shape;
	this.style = style;
	this.material = material;
	this.quantity = quantity;
	this.stockListingDate = stockListingDate;
	this.stockUpdateDate = LocalDate.now();
	this.price = price;
	this.discounts = discounts;
}


@Override
public String toString() {
	return "Watch [id=" + id + ", name=" + name + ", category=" + category + ", brand=" + brand + ", shape=" + shape
			+ ", style=" + style + ", material=" + material + ", quantity=" + quantity + ", stockListingDate="
			+ stockListingDate + ", stockUpdateDate=" + stockUpdateDate + ", price=" + price + ", discounts="
			+ discounts + "]";
}



public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public static int getIdGenerator() {
	return idGenerator;
}

public static void setIdGenerator(int idGenerator) {
	Watch.idGenerator = idGenerator;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Category getCategory() {
	return category;
}

public void setCategory(Category category) {
	this.category = category;
}

public Brand getBrand() {
	return brand;
}

public void setBrand(Brand brand) {
	this.brand = brand;
}

public Shape getShape() {
	return shape;
}

public void setShape(Shape shape) {
	this.shape = shape;
}

public Style getStyle() {
	return style;
}

public void setStyle(Style style) {
	this.style = style;
}

public WatchBrandMaterial getMaterial() {
	return material;
}

public void setMaterial(WatchBrandMaterial material) {
	this.material = material;
}

public int getQuantity() {
	return quantity;
}

public void setQuantity(int quantity) {
	this.quantity = quantity;
}

public LocalDate getStockListingDate() {
	return stockListingDate;
}

public void setStockListingDate(LocalDate stockListingDate) {
	this.stockListingDate = stockListingDate;
}

public LocalDate getStockUpdateDate() {
	return stockUpdateDate;
}

public void setStockUpdateDate(LocalDate stockUpdateDate) {
	this.stockUpdateDate = stockUpdateDate;
}

public int getPrice() {
	return price;
}

public void setPrice(int price) {
	this.price = price;
}

public int getDiscounts() {
	return discounts;
}

public void setDiscounts(int discounts) {
	this.discounts = discounts;
}


}








	








