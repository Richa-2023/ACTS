package tester;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import utils.WatchValidationRule.*;
import core_classes.Watch;
import static utils.WatchValidationRule.*;
public class Tester {
public static  void main(String[]args) {
	try(Scanner sc=new Scanner(System.in)){
		
		List<Watch>watchList=new ArrayList<>();
		
		boolean exit=false;
		
		while(!exit)
		{
			try {
				System.out.println("......Menu.......");
				System.out.println("1.Add new Watch");
				System.out.println("2.Update stock of a watch");
				System.out.println("3.Set discount of 10% for all the watch which are 1 year old");
				System.out.println("4.Remove watches which are never sold listed in 18 months");
				System.out.println("0.Exit");
				System.out.println("choose the option:");
				
				switch(sc.next()) {
				
				case 1:
					System.out.println("Enter name,category,brand,shape,style,material,quantity,listingDate,price,discount");
				Watch w=validateAllInputs(sc.next(),sc.next(),sc.next(),sc.next(),sc.next(),sc.next(),sc.nextInt(),sc.next(),sc.nextInt(),sc.nextInt());
				watchList.add(w);
				
				break;
				
				case 2:
					System.out.println("enter brand and quantity");
					UpdateStock(sc.next(),sc.nextInt(),watchList);
					break;
					
					
				case 3:
					System.out.println("enter brand and quantity");
					if(Period.between(w.getStockUpdateDate(), LocalDate.now()).toTotalMonths()>12)
						w.setDiscounts(10);
					break;
					
				case 4:
					for(Watch w:watchList)
						 RemoveNotSoldWatch(watchList);
					break;
					
				case 0:
					
					exit=true;
					break;
					
				}
				
				
			}catch(Exception e) {
				System.out.println(e);
				sc.nextLine();
			}
			
		}
		
	}
}
}
