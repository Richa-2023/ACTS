package tester;

import core_classes.Grocery;
import core_classes.GroceryItem;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import core_classes.Grocery;



public class Tester {
	
public static void main(String[]args) {
	try(Scanner sc=new Scanner(System.in) {
		List<Grocery>list=populatedList();
		
		
	}
}
}
