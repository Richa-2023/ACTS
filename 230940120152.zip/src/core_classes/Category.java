package core_classes;

public enum Category {
MEN,WOMEN,CHJILDERN;
}
