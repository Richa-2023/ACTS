package core_classes;

public enum GroceryItem {

}
