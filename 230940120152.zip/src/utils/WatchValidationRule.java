package utils;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeParseException;
import java.util.Iterator;
import java.util.List;
import java.util.Locale.Category;

import core_classes.Brand;
import core_classes.Shape;
import core_classes.Stock;
import core_classes.Style;
import core_classes.Watch;
import core_classes.WatchBrandMaterial;
import custom_exception.WatchHandlingException;

public class WatchValidationRule {

	private static void chkForDup(String name,List<Watch>watchList ) throws WatchHandlingException{
		Watch watch=new Watch(name);
		if(watchList.contains(watch))
		throw new Watch WatchHandlingException("Duplicate name...")
		System.out.println("No Duplication");
		
	}
	
	private static LocalDate parseAndValidate(String date)throws DateTimeParseException{
		return LocalDate.parse(date);
	}
	
	public static Category validateCategory(String category) throws WatchHandlingException{
		return Category.valueOf(category.toUpperCase());
	}
	
	public static Brand validateBrand(String brand) throws WatchHandlingException{
		return Brand.valueOf(brand.toUpperCase());
	}
	
	public static Shape validateShape(String shape) throws WatchHandlingException{
		return Shape.valueOf(shape.toUpperCase());
	}
	
	public static Style validateStyle(String style) throws WatchHandlingException{
		return Style.valueOf(style.toUpperCase());
	}
	
	public static WatchBrandMaterial validateWatchBrandMaterial(String material) throws WatchHandlingException{
		return WatchBrandMaterial.valueOf(material.toUpperCase());
	}
	
	public static Watch validateAllInputs( String name, String category, String brand,String shape, String style, String material,
		int quantity, String stockListingDate, int price, int discounts,List<Watch>watchList) throws WatchHandlingException,DateTimeParseException{
		chkForDup(name,watchList);
		LocalDate date1=parseAndValidate(stockListingDate);
		 Category category1=validateCategory(category);
		Brand brand1=validateBrand(brand);
		Shape shape1=validateShape(shape);
		Style style1=validateStyle(style);
		WatchBrandMaterial material1=validateWatchBrandMaterial(material);
		return new Watch(name,category1,brand1,shape1,style1,material1,quantity,date1,price,discounts);
			
	}
	public static void UpdateStock(String brand,int quantity,List<Watch>watchList)throws WatchHandlingException{
		
		Brand parseBrand=validateBrand(brand);
		for(Watch w:watchList) {
			if(w.getBrand()==parseBrand) {
				w.setQuantity(quantity);
				w.setStockUpdateDate(LocalDate.now());
			}
		}
			
	}
	
	public static void RemoveNotSoldWatch(List<Watch>watchList) {
	int counter=0;
	Iterator<Watch>itr=watchList.iterator();
	while(itr.hasNext()) {
		Watch w=itr.next();
		
		if((Period.between(w.getStockUpdateDate(),w.getStockListingDate())).toTotalMonths()>18) {
			 itr.remove();
			 counter++;
		}
			
	}
	}
	
	
}
