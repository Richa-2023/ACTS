package custom_exception;

public class WatchHandlingException extends Exception {
public WatchHandlingException(String ErrorMsg) {
	super(ErrorMsg);
}

}
