package core_classes;

public enum WatchBrandMaterial {
CERAMIC,STEEL,SILVER;
}
