package core_classes;

public enum Style {
CASUAL,SPORT,WEDDING;
}
