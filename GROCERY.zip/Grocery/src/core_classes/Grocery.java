package core_classes;

import java.time.LocalDate;
import java.time.LocalTime;

public class Grocery {
private String name;
private int pricePerUnit;
private int qty;
private LocalDate stockDate;
private LocalTime stockTime;


public Grocery(String name, int pricePerUnit, String stockDate ,  String stockTime) {
	super();
	this.name = name;
	this.pricePerUnit = pricePerUnit;
	this.qty = qty;
	this.stockDate=LocalDate.parse(stockDate);
	this.stockTime=LocalTime.parse(stockTime);
}


@Override
public String toString() {
	return "Grocery [name=" + name + ", pricePerUnit=" + pricePerUnit + ",stockDate=" + stockDate +",stockTime=" + stockTime +"]";
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public int getPricePerUnit() {
	return pricePerUnit;
}


public void setPricePerUnit(int pricePerUnit) {
	this.pricePerUnit = pricePerUnit;
}


public int getQty() {
	return qty;
}


public void setQty(int qty) {
	this.qty = qty;
}


public LocalDate getStockDate() {
	return stockDate;
}


public void setStockDate(LocalDate stockDate) {
	this.stockDate = stockDate;
}


public LocalTime getStockTime() {
	return stockTime;
}


public void setStockTime(LocalTime stockTime) {
	this.stockTime = stockTime;
}





}
