package core_classes;

public enum Brand {
CASIO,TITAN,FASTRACK;
}
