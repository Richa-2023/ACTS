package core_classes;

public enum Shape {
SQUARE,RECTANGLE,ROUND;
}
